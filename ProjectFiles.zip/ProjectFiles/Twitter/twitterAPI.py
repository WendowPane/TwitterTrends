# Import the necessary package to process data in JSON format
try:
    import json
except ImportError:
    import simplejson as json

import timeit
import gmplot
# Import the necessary methods from "twitter" library
from twitter import Twitter, OAuth, TwitterHTTPError, TwitterStream

# Variables that contains the user credentials to access Twitter API 
ACCESS_TOKEN = '416787324-KDKNBoKrqtzljfrUhKFgyrsY2TjM86DhucBTyvDE'
ACCESS_SECRET = 'zCm12HhaswpRizUHorZQCV6HWGp8xeyBXPoAeUvo3QnzU'
CONSUMER_KEY ='ThOCIBPAozMF7do5R7vlSuCYf'
CONSUMER_SECRET = '6oqRr6eCOdJtTrZYf0ugIC7ckxMmbvS0ZlfoHpMBtbOFZzi1JR'

oauth = OAuth(ACCESS_TOKEN, ACCESS_SECRET, CONSUMER_KEY, CONSUMER_SECRET)

# Initiate the connection to Twitter Streaming API
twitter_stream = TwitterStream(auth=oauth)

# Get a sample of the public data following through Twitter
iterator = twitter_stream.statuses.filter(track= None, language="en")

#iterator = twitter_stream.statuses.filter(location= "USA", language="en") 
#39.8,-95.583068847, 656,2500km (US LATLONG AND RADIUS FOR LOWER 48 STATES)
# Print each tweet in the stream to the screen 
# Here we set it to stop after getting 1000 tweets. 
# You don't have to set it to stop, but can continue running 
# the Twitter API to collect data for days or even longer.

def getTweets(numTweets):
    lats = []
    longs = []
    newTweetInfo = []
    for tweet in iterator:
        # Twitter Python Tool wraps the data returned by Twitter 
        # as a TwitterDictResponse object.
        # We convert it back to the JSON format to print/score
        allTweetInfo = json.loads(json.dumps(tweet))
        if allTweetInfo['user']['location'] != None:
            try:
                #print(allTweetInfo['user']['location'])
                latlong = gmplot.GoogleMapPlotter.geocode(allTweetInfo['user']['location'])
                #CODE BELOW ONLY APPENDS LAT,LONG
                lats.append(latlong[0])
                longs.append(latlong[1])
                #CODE BELOW APPENDS BOTH TEXT AND LOCATION
                #newTweetInfo.append([latlong, allTweetInfo['text']])
            except IndexError:
                pass
        if len(lats) == numTweets:
           break
    newTweetInfo.append(lats)
    newTweetInfo.append(longs)
    return newTweetInfo


